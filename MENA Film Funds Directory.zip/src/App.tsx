import React, { useState, useMemo } from 'react';
import { Search, Filter, Globe2, SortAsc, MapPin } from 'lucide-react';
import { filmFunds } from './data/filmFunds';
import { FilmFund, SortOption } from './types';

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedCountry, setSelectedCountry] = useState<string>('all');
  const [sortBy, setSortBy] = useState<SortOption>('programName');

  const categories = [
    'all',
    'Major Regional',
    'International',
    'National',
    'Labs',
    'Distribution',
    'Festival Awards',
    'Other'
  ];

  const countries = useMemo(() => {
    const uniqueCountries = Array.from(
      new Set(filmFunds.map(fund => fund.applicationCountry))
    ).sort();
    return ['all', ...uniqueCountries];
  }, []);

  const filteredAndSortedFunds = useMemo(() => {
    return filmFunds
      .filter(fund => {
        const matchesSearch = 
          fund.programName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          fund.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          fund.applicationCountry.toLowerCase().includes(searchTerm.toLowerCase()) ||
          fund.targetRegion.toLowerCase().includes(searchTerm.toLowerCase());

        const matchesCategory = 
          selectedCategory === 'all' || 
          fund.category.toLowerCase() === selectedCategory.toLowerCase();

        const matchesCountry =
          selectedCountry === 'all' ||
          fund.applicationCountry === selectedCountry;

        return matchesSearch && matchesCategory && matchesCountry;
      })
      .sort((a, b) => {
        switch (sortBy) {
          case 'programName':
            return a.programName.localeCompare(b.programName);
          case 'applicationCountry':
            return a.applicationCountry.localeCompare(b.applicationCountry);
          case 'category':
            return a.category.localeCompare(b.category);
          case 'targetRegion':
            return a.targetRegion.localeCompare(b.targetRegion);
          default:
            return 0;
        }
      });
  }, [searchTerm, selectedCategory, selectedCountry, sortBy]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Globe2 className="h-8 w-8 text-indigo-600" />
            <h1 className="text-2xl font-bold text-gray-900">MENA Film Funds Directory</h1>
          </div>
          <p className="text-sm text-gray-500">Supporting MENA Filmmakers Worldwide</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {/* Search, Filter, and Sort Section */}
        <div className="mb-8 grid gap-4 md:grid-cols-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search funds, programs, or countries..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="text-gray-400 h-5 w-5" />
            <select
              className="flex-1 py-2 px-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              {categories.map((category) => (
                <option key={category} value={category.toLowerCase()}>
                  {category === 'all' ? 'All Categories' : category}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-center space-x-2">
            <MapPin className="text-gray-400 h-5 w-5" />
            <select
              className="flex-1 py-2 px-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
            >
              {countries.map((country) => (
                <option key={country} value={country}>
                  {country === 'all' ? 'All Countries' : country}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-center space-x-2">
            <SortAsc className="text-gray-400 h-5 w-5" />
            <select
              className="flex-1 py-2 px-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
            >
              <option value="programName">Sort by Name</option>
              <option value="applicationCountry">Sort by Country</option>
              <option value="category">Sort by Category</option>
              <option value="targetRegion">Sort by Target Region</option>
            </select>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-4">
          <p className="text-sm text-gray-600">
            Showing {filteredAndSortedFunds.length} results
          </p>
        </div>

        {/* Funds Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredAndSortedFunds.map((fund) => (
            <div key={fund.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{fund.programName}</h3>
              <p className="text-sm text-gray-600 mb-4">{fund.description}</p>
              <div className="space-y-2">
                <div className="flex items-start space-x-2">
                  <span className="text-sm font-medium text-gray-500">Region:</span>
                  <span className="text-sm text-gray-900">{fund.targetRegion}</span>
                </div>
                <div className="flex items-start space-x-2">
                  <span className="text-sm font-medium text-gray-500">Base:</span>
                  <span className="text-sm text-gray-900">{fund.applicationCountry}</span>
                </div>
                <div className="flex items-start space-x-2">
                  <span className="text-sm font-medium text-gray-500">Deadlines:</span>
                  <span className="text-sm text-gray-900">{fund.submissionDates}</span>
                </div>
                <div className="flex items-start space-x-2">
                  <span className="text-sm font-medium text-gray-500">Category:</span>
                  <span className="text-sm text-gray-900">{fund.category}</span>
                </div>
              </div>
              <a
                href={fund.websiteLink}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 inline-flex items-center text-indigo-600 hover:text-indigo-500"
              >
                Visit Website
                <svg className="ml-1 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                </svg>
              </a>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

export default App;