import { FilmFund } from '../types';

// Note: Some entries marked with "(Former)" or "(Paused)" indicate programs that are no longer active or their current status is uncertain,
// but they are included for historical context or potential future revival. Check websites for the latest information.

export const filmFunds: FilmFund[] = [
  // ===== Existing Entries (Optimized & Merged) =====
  {
    id: 1,
    programName: "Doha Film Institute (DFI) Grants",
    description: "Development, Production, Post-Production (Features, Docs, Shorts, Series)",
    targetRegion: "MENA & International (MENA Priority)",
    applicationCountry: "Qatar",
    submissionDates: "Annual Cycles (Spring, Fall)",
    websiteLink: "https://www.dohafilminstitute.com/financing/grants/guidelines",
    category: "Major Regional"
  },
  {
    id: 2,
    programName: "AFAC (Arab Fund for Arts and Culture) Cinema Grant",
    description: "Development, Production, Post-Production (Features, Docs)",
    targetRegion: "Arab Nationals/Residents",
    applicationCountry: "Lebanon", // Based regionally
    submissionDates: "Annual (Usually Spring)",
    websiteLink: "https://www.arabculturefund.org/",
    category: "Major Regional"
  },
  {
    id: 3,
    programName: "Red Sea Fund",
    description: "Development, Production, Post-Production (Features, Docs, Shorts, Episodic)",
    targetRegion: "Arab & African Filmmakers",
    applicationCountry: "Saudi Arabia",
    submissionDates: "Cycles Announced",
    websiteLink: "https://redseafilmfest.com/en/red-sea-fund/",
    category: "Major Regional"
  },
  {
    id: 4,
    programName: "Red Sea Lodge",
    description: "Script & Feature Film Development Lab (in partnership with TorinoFilmLab)",
    targetRegion: "Saudi & Arab Teams",
    applicationCountry: "Saudi Arabia",
    submissionDates: "Annual",
    websiteLink: "https://redseafilmfest.com/en/red-sea-lodge/",
    category: "Labs"
  },
  {
    id: 5,
    programName: "Qumra (Doha Film Institute)",
    description: "Project Development Incubator (Mentorship, Masterclasses, Meetings)",
    targetRegion: "DFI Grantee Projects",
    applicationCountry: "Qatar",
    submissionDates: "Annual (Invitation/Selection)",
    websiteLink: "https://www.dohafilminstitute.com/qumra",
    category: "Labs"
  },
  {
    id: 6,
    programName: "Cairo Film Connection (CFC)",
    description: "Co-production Platform (Awards, Meetings)",
    targetRegion: "Arab Directors/Producers",
    applicationCountry: "Egypt",
    submissionDates: "Annual (During CIFF)",
    websiteLink: "https://www.ciff.org.eg/cairo-industry-days-2/",
    category: "Major Regional" // Often considered a market/platform
  },
  {
    id: 7,
    programName: "Atlas Workshops",
    description: "Development & Post-Production Support & Consultation",
    targetRegion: "Arab & African Filmmakers",
    applicationCountry: "Morocco",
    submissionDates: "Annual (During FIFM)",
    websiteLink: "https://marrakech-festival.com/en/atlas-workshops/",
    category: "Labs" // Primarily a development/support platform
  },
  {
    id: 8,
    programName: "IDFA Bertha Fund",
    description: "Development, Production, Post-Production (Focus on Docs)",
    targetRegion: "Filmmakers from Africa, Asia, LatAm, MidEast, E.Europe",
    applicationCountry: "Netherlands",
    submissionDates: "Annual Cycles (Spring/Fall)",
    websiteLink: "https://www.idfa.nl/en/info/idfa-bertha-fund",
    category: "International"
  },
  {
    id: 9,
    programName: "Hubert Bals Fund (IFFR)",
    description: "Development, Production, Post-Production",
    targetRegion: "Filmmakers from Africa, Asia, LatAm, MidEast, E.Europe",
    applicationCountry: "Netherlands",
    submissionDates: "Annual Cycles",
    websiteLink: "https://iffr.com/en/hubert-bals-fund",
    category: "International"
  },
  {
    id: 10,
    programName: "World Cinema Fund (Berlinale)",
    description: "Production & Distribution Support",
    targetRegion: "Filmmakers from WCF Regions (Incl. MENA)",
    applicationCountry: "Germany",
    submissionDates: "Two Cycles Annually",
    websiteLink: "https://www.berlinale.de/en/wcf/home/index.html",
    category: "International"
  },
  {
    id: 11,
    programName: "CineGouna Platform",
    description: "Co-production Market & Development Lab (Awards, Meetings)",
    targetRegion: "Arab Directors/Producers",
    applicationCountry: "Egypt",
    submissionDates: "Annual (During GFF)",
    websiteLink: "https://elgounafilmfestival.com/cinegouna-platform/",
    category: "Major Regional" // Market/Platform with awards
  },
  {
    id: 12,
    programName: "Malmö Arab Film Festival (MAFF) Industry Days",
    description: "Development Funding, Co-production Market, Networking",
    targetRegion: "Arab & Nordic Co-productions/Filmmakers",
    applicationCountry: "Sweden",
    submissionDates: "Annual (During MAFF)",
    websiteLink: "https://maffswe.com/industry-days-2024/",
    category: "International" // Market/Platform with funding
  },
  {
    id: 13,
    programName: "Takmil (Carthage Film Festival - JCC)",
    description: "Post-Production Workshop & Grants (Features, Docs)",
    targetRegion: "African & Arab Filmmakers",
    applicationCountry: "Tunisia",
    submissionDates: "Annual (During JCC)",
    websiteLink: "https://www.jcctunisie.org/jccinstach.php", // Link covers JCC Industry
    category: "Major Regional" // Post-production focus
  },
  {
    id: 14,
    programName: "Jordan Film Fund (Royal Film Commission - RFC)",
    description: "Development, Production, Post-Production (Various Formats)",
    targetRegion: "Jordanian & International (Shooting in Jordan)",
    applicationCountry: "Jordan",
    submissionDates: "Multiple Cycles Annually",
    websiteLink: "https://film.jo/jordan-film-fund-jff/",
    category: "National"
  },
  {
    id: 15,
    programName: "Rawi Screenwriters Lab (RFC Jordan)",
    description: "Feature Script Development Lab (Mentorship)",
    targetRegion: "Arab Screenwriters",
    applicationCountry: "Jordan",
    submissionDates: "Annual",
    websiteLink: "https://film.jo/rawi-screenwriters-lab/",
    category: "Labs"
  },
  {
    id: 16,
    programName: "MAD Solutions",
    description: "Distribution, Marketing, Promotion in the Arab World",
    targetRegion: "Arab Films",
    applicationCountry: "Egypt/UAE", // Operates regionally
    submissionDates: "Contact/Submission Basis",
    websiteLink: "https://mad-solutions.com/",
    category: "Distribution"
  },
  {
    id: 17,
    programName: "Beirut DC",
    description: "Various Programs (Production, Training, Distribution)",
    targetRegion: "Lebanese & Arab Filmmakers",
    applicationCountry: "Lebanon",
    submissionDates: "Varies per Program",
    websiteLink: "https://beirutdc.org/",
    category: "Major Regional" // Acts as a support organization
  },
  {
    id: 18,
    programName: "Chabaka (Carthage Pro - JCC)",
    description: "Development Workshop & Co-production Platform",
    targetRegion: "African & Arab Projects",
    applicationCountry: "Tunisia",
    submissionDates: "Annual (During JCC)",
    websiteLink: "https://www.jcctunisie.org/jccinstach.php", // Link covers JCC Industry
    category: "Labs" // Development focus
  },
  // ID 19 was a duplicate of Red Sea Lodge (ID 4), removed.
  {
    id: 20,
    programName: "Tanit d'Or (Carthage Film Festival - JCC)",
    description: "Main Competition Award (Features, Docs, Shorts)",
    targetRegion: "African & Arab Films",
    applicationCountry: "Tunisia",
    submissionDates: "Annual (During JCC)",
    websiteLink: "https://www.jcctunisie.org/",
    category: "Festival Awards"
  },

  // ===== New Entries from Table (Starting ID 21) =====

  // Major Regional Funds & Institutions (Cont.)
  {
    id: 21, // Was Table #4
    programName: "Red Sea Souk - Project Market",
    description: "Co-production Market, Meetings, Awards",
    targetRegion: "Arab & African Projects",
    applicationCountry: "Saudi Arabia",
    submissionDates: "Annual (During Festival)",
    websiteLink: "https://redseafilmfest.com/en/red-sea-souk/",
    category: "Major Regional" // Market/Platform
  },
  {
    id: 22, // Was Table #16
    programName: "Med Film Factory (RFC Jordan)",
    description: "Development & Production Workshop for Teams",
    targetRegion: "Jordanian & Arab Filmmakers",
    applicationCountry: "Jordan",
    submissionDates: "Check Website (Past Program, Status Unclear)",
    websiteLink: "https://film.jo/med-film-factory/", // Check for updates
    category: "Labs"
  },
  {
    id: 23, // Was Table #17
    programName: "The Film Prize of the Robert Bosch Stiftung (Former)",
    description: "Co-production Germany/Arab World (Focus on Docs, Animation, Shorts)",
    targetRegion: "German-Arab Teams",
    applicationCountry: "Germany",
    submissionDates: "Program Ended - Check Successors/Archives",
    websiteLink: "", // No active link for the ended program
    category: "Historical"
  },
  {
    id: 24, // Was Table #18
    programName: "Arab Cinema Center (ACC)",
    description: "Promotion, Networking, Awards (Critics Awards, Achievement Award)",
    targetRegion: "Arab Cinema & Professionals",
    applicationCountry: "Regional/International",
    submissionDates: "Ongoing / Event-Based",
    websiteLink: "https://acc.film/",
    category: "Industry Body" // Promotion & Networking
  },
  {
    id: 25, // Was Table #19
    programName: "Arab Film Institute (AFI)",
    description: "Database, Resources, Networking",
    targetRegion: "Arab Cinema Professionals",
    applicationCountry: "Regional/International",
    submissionDates: "Ongoing",
    websiteLink: "https://arabfilminstitute.org/",
    category: "Industry Body" // Resource & Networking
  },
  {
    id: 26, // Was Table #20
    programName: "SANAD Fund (Abu Dhabi - Former)",
    description: "Development & Post-Production Grants",
    targetRegion: "Arab Filmmakers",
    applicationCountry: "UAE",
    submissionDates: "Program Paused/Ended - Historical Reference",
    websiteLink: "", // No active link
    category: "Historical"
  },
  {
    id: 27, // Was Table #21
    programName: "Enjaaz (Dubai Film Market - Former)",
    description: "Post-Production & Production Support",
    targetRegion: "Arab Filmmakers",
    applicationCountry: "UAE",
    submissionDates: "Program Paused/Ended with DIFF",
    websiteLink: "", // No active link
    category: "Historical"
  },
  {
    id: 28, // Was Table #22
    programName: "Image Nation Abu Dhabi",
    description: "Funding, Production, Training (Various Programs)",
    targetRegion: "Emirati & International",
    applicationCountry: "UAE",
    submissionDates: "Varies - Check Website",
    websiteLink: "https://imagenationabudhabi.com/",
    category: "Major Regional" // Significant regional production house/funder
  },
  {
    id: 29, // Was Table #23
    programName: "OIF - Fonds Image de la Francophonie",
    description: "Production, Post-Production Support",
    targetRegion: "Francophone Countries (Incl. several MENA nations)",
    applicationCountry: "France (International)",
    submissionDates: "Annual Cycles - Check Website",
    websiteLink: "https://www.imagesfrancophones.org/",
    category: "International"
  },
  {
    id: 30, // Was Table #24
    programName: "CNC Aide aux cinémas du monde",
    description: "Selective Co-production Support (Development, Production)",
    targetRegion: "International Co-productions with France",
    applicationCountry: "France",
    submissionDates: "Multiple Deadlines Annually - Check Website",
    websiteLink: "https://www.cnc.fr/professionnels/aides-et-financements/cinema/aides-aux-cinemas-du-monde",
    category: "International"
  },

  // International Funds Often Supporting MENA Projects
  {
    id: 31, // Was Table #28
    programName: "Sørfond (Norwegian South Film Fund)",
    description: "Production Support for Co-productions with Norway",
    targetRegion: "Filmmakers from Eligible Countries (Incl. some MENA)",
    applicationCountry: "Norway",
    submissionDates: "Annual - Check Website",
    websiteLink: "https://www.sorfond.no/",
    category: "International"
  },
  {
    id: 32, // Was Table #29
    programName: "Visions Sud Est",
    description: "Production & Post-Production Support",
    targetRegion: "Filmmakers from Asia, Africa, LatAm, E.Europe (Incl. MENA)",
    applicationCountry: "Switzerland",
    submissionDates: "Multiple Cycles Annually - Check Website",
    websiteLink: "https://www.visionssudest.ch/en/",
    category: "International"
  },
  {
    id: 33, // Was Table #30
    programName: "Creative Europe MEDIA - International Co-production",
    description: "Support for Co-productions between EU & non-EU companies",
    targetRegion: "EU & Eligible non-EU Countries (Potentially MENA)",
    applicationCountry: "EU",
    submissionDates: "Annual Calls - Check Portal",
    websiteLink: "https://ec.europa.eu/info/funding-tenders/opportunities/portal/screen/home", // General portal link
    category: "International"
  },
  {
    id: 34, // Was Table #31
    programName: "Sundance Institute Feature Film Program",
    description: "Labs (Screenwriting, Directing, Producing), Grants",
    targetRegion: "International (Incl. MENA)",
    applicationCountry: "USA",
    submissionDates: "Various Deadlines - Check Website",
    websiteLink: "https://www.sundance.org/programs/feature-film/",
    category: "Labs" // Also includes grants, but known for labs
  },
  {
    id: 35, // Was Table #32
    programName: "Sundance Institute Documentary Fund",
    description: "Development, Production, Post-Production Grants",
    targetRegion: "International (Incl. MENA)",
    applicationCountry: "USA",
    submissionDates: "Rolling or Cycles - Check Website",
    websiteLink: "https://www.sundance.org/programs/documentary-fund/",
    category: "International"
  },
  {
    id: 36, // Was Table #33
    programName: "Chicken & Egg Pictures",
    description: "Grants & Mentorship for Women Non-fiction Filmmakers",
    targetRegion: "International (Incl. MENA)",
    applicationCountry: "USA",
    submissionDates: "Annual Calls - Check Website",
    websiteLink: "https://chickeneggpics.org/",
    category: "International"
  },
  {
    id: 37, // Was Table #34
    programName: "Catapult Film Fund",
    description: "Development Funding for Documentary Films",
    targetRegion: "International (Incl. MENA)",
    applicationCountry: "USA",
    submissionDates: "Rolling Basis - Check Website",
    websiteLink: "https://catapultfilmfund.org/",
    category: "International"
  },
  {
    id: 38, // Was Table #35
    programName: "Hot Docs Funds (CrossCurrents, Blue Ice Docs, etc.)",
    description: "Various Funds for Documentaries (Some Int'l/Regional Focus)",
    targetRegion: "Varies by Fund (Check Eligibility)",
    applicationCountry: "Canada",
    submissionDates: "Annual Cycles - Check Website",
    websiteLink: "https://hotdocs.ca/industry/funds",
    category: "International"
  },
  {
    id: 39, // Was Table #36
    programName: "Alter-Ciné Foundation",
    description: "Documentary Production Grant",
    targetRegion: "Filmmakers from Asia, Africa, LatAm",
    applicationCountry: "Canada",
    submissionDates: "Annual - Check Website",
    websiteLink: "http://altercine.org/",
    category: "International"
  },
  {
    id: 40, // Was Table #37
    programName: "The Film Fund (by Backstage)",
    description: "Short Film Funding (Pitch-based)",
    targetRegion: "International",
    applicationCountry: "USA",
    submissionDates: "Monthly/Regularly - Check Website",
    websiteLink: "https://www.thefilmfund.co/",
    category: "International" // Focus on shorts
  },
  {
    id: 41, // Was Table #38
    programName: "Screen Australia - International Co-production",
    description: "Co-production funding with Australia",
    targetRegion: "Official Co-production Treaties/MOUs (Check if MENA countries apply)",
    applicationCountry: "Australia",
    submissionDates: "Check Website",
    websiteLink: "https://www.screenaustralia.gov.au/funding-and-support/co-production-program",
    category: "International"
  },
  {
    id: 42, // Was Table #39
    programName: "Telefilm Canada - International Co-production",
    description: "Co-production funding with Canada",
    targetRegion: "Official Co-production Treaties (Check if MENA countries apply)",
    applicationCountry: "Canada",
    submissionDates: "Check Website",
    websiteLink: "https://telefilm.ca/en/funding/international-coproduction",
    category: "International"
  },
  {
    id: 43, // Was Table #40
    programName: "Ford Foundation - JustFilms",
    description: "Funding for Social Justice Storytelling (Film/VR/New Media)",
    targetRegion: "International (Focus Regions Vary)",
    applicationCountry: "USA (Global Offices)",
    submissionDates: "Inquiry/Rolling Basis - Check Website",
    websiteLink: "https://www.fordfoundation.org/work/our-grants/justfilms/",
    category: "International"
  },
  {
    id: 44, // Was Table #41
    programName: "Open Society Foundations - Culture & Art",
    description: "Grants supporting arts for open society dialogue",
    targetRegion: "Varies by Call/Region",
    applicationCountry: "USA (Global Network)",
    submissionDates: "Check Current Opportunities",
    websiteLink: "https://www.opensocietyfoundations.org/",
    category: "International"
  },

  // National Funds & Support (Examples)
  {
    id: 45, // Was Table #42
    programName: "Centre Cinématographique Marocain (CCM) - Fonds d'aide",
    description: "Production Support (National & Co-production)",
    targetRegion: "Moroccan & Co-productions",
    applicationCountry: "Morocco",
    submissionDates: "Multiple Sessions Annually - Check Website",
    websiteLink: "http://www.ccm.ma/",
    category: "National"
  },
  {
    id: 46, // Was Table #43
    programName: "CNCI (Centre National du Cinéma et de l'Image) - Fonds d'encouragement",
    description: "Production & Scriptwriting Support",
    targetRegion: "Tunisian Filmmakers",
    applicationCountry: "Tunisia",
    submissionDates: "Check Website",
    websiteLink: "http://www.cnci.tn/",
    category: "National"
  },
  {
    id: 47, // Was Table #44
    programName: "FDATIC (Fonds de Développement de l'Art, Technique et Industrie Cinematographiques)",
    description: "Production Support",
    targetRegion: "Algerian Filmmakers",
    applicationCountry: "Algeria",
    submissionDates: "Check Ministry of Culture Website/News",
    websiteLink: "", // Usually announced via Ministry
    category: "National"
  },
  {
    id: 48, // Was Table #45
    programName: "Ministry of Culture - Lebanon",
    description: "Film Support (Can be inconsistent)",
    targetRegion: "Lebanese Filmmakers",
    applicationCountry: "Lebanon",
    submissionDates: "Check Ministry Website/News",
    websiteLink: "", // Check official Ministry channels
    category: "National"
  },
  {
    id: 49, // Was Table #46
    programName: "Saudi Film Commission",
    description: "Various Initiatives, Funds, Training",
    targetRegion: "Saudi Filmmakers",
    applicationCountry: "Saudi Arabia",
    submissionDates: "Varies - Check Website",
    websiteLink: "https://film.moc.gov.sa/en",
    category: "National"
  },
  {
    id: 50, // Was Table #47
    programName: "Ithra (King Abdulaziz Center for World Culture)",
    description: "Film Grants, Production Support, Training",
    targetRegion: "Saudi & Arab Filmmakers",
    applicationCountry: "Saudi Arabia",
    submissionDates: "Varies - Check Website",
    websiteLink: "https://www.ithra.com/en/",
    category: "National" // Also supports regional
  },
  {
    id: 51, // Was Table #48
    programName: "Egypt Ministry of Culture - Film Funds",
    description: "National Film Support",
    targetRegion: "Egyptian Filmmakers",
    applicationCountry: "Egypt",
    submissionDates: "Check Ministry Website/News",
    websiteLink: "", // Check official Ministry channels
    category: "National"
  },
  {
    id: 52, // Was Table #49
    programName: "Sharjah Art Foundation",
    description: "Film Grants, Production Support (Often contemporary art focus)",
    targetRegion: "International (Incl. MENA)",
    applicationCountry: "UAE (Sharjah)",
    submissionDates: "Check Website for Calls",
    websiteLink: "https://sharjahart.org/",
    category: "National" // Based in Sharjah, supports internationally
  },
  {
    id: 53, // Was Table #50
    programName: "MiSK Art Institute",
    description: "Grants and programs sometimes including film/media",
    targetRegion: "Saudi & Arab Artists",
    applicationCountry: "Saudi Arabia",
    submissionDates: "Check Website for Calls",
    websiteLink: "https://miskartinstitute.org/",
    category: "National" // Primarily arts focus
  },

  // Labs, Workshops & Residencies (Selection)
  {
    id: 54, // Was Table #51
    programName: "TorinoFilmLab (TFL)",
    description: "Various Labs (Script, Feature, Series, Audience Design)",
    targetRegion: "International (Often partners with MENA initiatives)",
    applicationCountry: "Italy",
    submissionDates: "Annual Calls - Check Website",
    websiteLink: "http://www.torinofilmlab.it/",
    category: "Labs"
  },
  {
    id: 55, // Was Table #52
    programName: "Berlinale Talents",
    description: "Networking & Development Program for Emerging Filmmakers",
    targetRegion: "International",
    applicationCountry: "Germany",
    submissionDates: "Annual - Check Website",
    websiteLink: "https://www.berlinale-talents.de/",
    category: "Labs" // Talent development program
  },
  {
    id: 56, // Was Table #53
    programName: "Talents Beirut (Former)",
    description: "Networking & Development Program for Arab Filmmakers (in partnership with Berlinale)",
    targetRegion: "Arab Filmmakers",
    applicationCountry: "Lebanon",
    submissionDates: "Program Paused/Ended - Historical Reference",
    websiteLink: "", // No active link
    category: "Historical"
  },
  {
    id: 57, // Was Table #54
    programName: "Locarno Open Doors (Focus Regions Vary)",
    description: "Co-production Hub, Producers Lab, Screenings (Sometimes MENA focus)",
    targetRegion: "Filmmakers from Focus Region",
    applicationCountry: "Switzerland",
    submissionDates: "Annual - Check Website",
    websiteLink: "https://www.locarnofestival.ch/LFF/pro/open-doors.html",
    category: "Labs" // Also Market elements
  },
  {
    id: 58, // Was Table #55
    programName: "La Fabrique Cinéma (Cannes Film Festival)",
    description: "Development Support & Market Exposure for First/Second Features",
    targetRegion: "Filmmakers from Emerging Countries (Incl. MENA)",
    applicationCountry: "France",
    submissionDates: "Annual - Check Website",
    websiteLink: "https://www.lescinemasdumonde.com/en/la-fabrique/",
    category: "Labs" // Development program at Cannes
  },
  {
    id: 59, // Was Table #56
    programName: "Résidence de la Cinéfondation (Cannes Film Festival)",
    description: "Feature Film Scriptwriting Residency",
    targetRegion: "Emerging International Filmmakers",
    applicationCountry: "France",
    submissionDates: "Two Sessions Annually - Check Website",
    websiteLink: "https://www.cinefondation.com/en/residence",
    category: "Labs" // Residency
  },
  {
    id: 60, // Was Table #57
    programName: "Moulin d'Andé - CECI",
    description: "Scriptwriting Residency",
    targetRegion: "International",
    applicationCountry: "France",
    submissionDates: "Multiple Deadlines - Check Website",
    websiteLink: "https://www.moulinande.com/ceci",
    category: "Labs" // Residency
  },
  {
    id: 61, // Was Table #58
    programName: "Full Circle Lab (Various Locations)",
    description: "Development Workshop (Often linked to festivals)",
    targetRegion: "Varies by Lab Location/Focus",
    applicationCountry: "International",
    submissionDates: "Varies - Check Website",
    websiteLink: "https://fullcirclelab.org/",
    category: "Labs"
  },
  {
    id: 62, // Was Table #59
    programName: "EAVE (European Audiovisual Entrepreneurs)",
    description: "Producers Workshop, Ties That Bind (Europe/Asia), PUENTES (Europe/LatAm)",
    targetRegion: "International Producers (Some programs relevant for co-pro)",
    applicationCountry: "Luxembourg (Int'l)",
    submissionDates: "Annual Calls - Check Website",
    websiteLink: "https://eave.org/",
    category: "Labs" // Producer training
  },
  {
    id: 63, // Was Table #60
    programName: "Dok Incubator",
    description: "Rough-Cut Documentary Workshop",
    targetRegion: "International",
    applicationCountry: "Czech Republic (Int'l)",
    submissionDates: "Annual Call - Check Website",
    websiteLink: "https://dokincubator.net/",
    category: "Labs" // Post-production workshop
  },
  {
    id: 64, // Was Table #61
    programName: "EsoDoc (European Social Documentary)",
    description: "Training for filmmakers working with social themes/transmedia",
    targetRegion: "International",
    applicationCountry: "Italy (Int'l)",
    submissionDates: "Annual Call - Check Website",
    websiteLink: "https://www.esodoc.eu/",
    category: "Labs"
  },
  {
    id: 65, // Was Table #62
    programName: "CIRCLE Women Doc Accelerator",
    description: "Development Lab for Women Directors/Producers (Docs)",
    targetRegion: "International",
    applicationCountry: "Montenegro (Int'l)",
    submissionDates: "Annual Call - Check Website",
    websiteLink: "https://doccircle.me/",
    category: "Labs"
  },
  {
    id: 66, // Was Table #63
    programName: "Close Up Initiative",
    description: "Development Lab for MENA & SE Asian Documentary Filmmakers",
    targetRegion: "MENA & SE Asia",
    applicationCountry: "International", // Runs internationally
    submissionDates: "Annual Call - Check Website",
    websiteLink: "https://www.closeupinitiative.org/",
    category: "Labs"
  },
  {
    id: 67, // Was Table #64
    programName: "Meditalents",
    description: "Scriptwriting Labs & Residencies",
    targetRegion: "Mediterranean Filmmakers",
    applicationCountry: "Morocco/France",
    submissionDates: "Check Website (Check Status)",
    websiteLink: "http://meditalents.net/",
    category: "Labs"
  },
  {
    id: 68, // Was Table #65
    programName: "Green Khemis (Part of Atlas Workshops)",
    description: "Development lab for Moroccan filmmakers",
    targetRegion: "Moroccan filmmakers",
    applicationCountry: "Morocco",
    submissionDates: "Annual (via Atlas Workshops)",
    websiteLink: "https://marrakech-festival.com/en/atlas-workshops/", // Part of Atlas
    category: "Labs"
  },
  {
    id: 69, // Was Table #66
    programName: "Produire au Sud (Festival des 3 Continents)",
    description: "Co-production Workshop for Producers/Directors",
    targetRegion: "Africa, Asia, LatAm",
    applicationCountry: "France",
    submissionDates: "Annual Calls - Check Website",
    websiteLink: "https://www.3continents.com/en/produire-au-sud/",
    category: "Labs"
  },
  {
    id: 70, // Was Table #67
    programName: "Ouaga Film Lab",
    description: "Development & Co-production Lab",
    targetRegion: "West African focus, but check eligibility",
    applicationCountry: "Burkina Faso",
    submissionDates: "Annual Call - Check Website",
    websiteLink: "https://www.ouagafilmlab.net/",
    category: "Labs"
  },
  {
    id: 71, // Was Table #68
    programName: "DEENTAL ACP (CNC Support)",
    description: "Production Support for ACP-EU Co-productions",
    targetRegion: "ACP Countries (Incl. some MENA/African nations) & EU",
    applicationCountry: "France",
    submissionDates: "Check CNC Website",
    websiteLink: "https://www.cnc.fr/professionnels/aides-et-financements/cinema/deental-acp",
    category: "International" // Fund administered via CNC
  },
  {
    id: 72, // Was Table #69
    programName: "IEFTA (Intl Emerging Film Talent Association)",
    description: "Support, mentorship, festival access for emerging filmmakers",
    targetRegion: "Focus regions vary (Check for MENA initiatives)",
    applicationCountry: "Monaco",
    submissionDates: "Varies - Check Website",
    websiteLink: "https://www.iefta.org/",
    category: "Labs" // Primarily mentorship & support
  },
  {
    id: 73, // Was Table #70
    programName: "CPH:LAB (CPH:DOX)",
    description: "Talent Development Program for innovative projects",
    targetRegion: "International",
    applicationCountry: "Denmark",
    submissionDates: "Annual Call - Check Website",
    websiteLink: "https://cphdox.dk/industry/cphlab/",
    category: "Labs"
  },
  {
    id: 74, // Was Table #108
    programName: "FilmLab Palestine",
    description: "Workshops, Training, Production Support",
    targetRegion: "Palestinian Filmmakers",
    applicationCountry: "Palestine",
    submissionDates: "Varies - Check Website",
    websiteLink: "https://www.flp.ps/en/film-lab",
    category: "Labs" // Also National Support
  },

  // Distribution & Promotion Support
  // ID 16 (MAD Solutions) already covered
  {
    id: 75, // Was Table #72
    programName: "Trigon-Film",
    description: "Distribution Support for Films from Africa, Asia, LatAm",
    targetRegion: "Films from supported regions",
    applicationCountry: "Switzerland",
    submissionDates: "Contact/Submission Basis",
    websiteLink: "https://www.trigon-film.org/",
    category: "Distribution"
  },
  {
    id: 76, // Was Table #73
    programName: "EFP (European Film Promotion) - Film Sales Support",
    description: "Support for sales agents promoting European films outside Europe",
    targetRegion: "European Sales Agents (May apply to co-pros)",
    applicationCountry: "EU (Based in Hamburg)",
    submissionDates: "Multiple Deadlines - Check Website",
    websiteLink: "https://www.efp-online.com/en/project_market/film_sales_support.php",
    category: "Distribution" // Sales agent support
  },
  {
    id: 77, // Was Table #74
    programName: "UniFrance",
    description: "Promotion of French films abroad (Incl. co-productions)",
    targetRegion: "French Films & Co-productions",
    applicationCountry: "France",
    submissionDates: "Ongoing",
    websiteLink: "https://en.unifrance.org/",
    category: "Distribution" // Promotion Body
  },
  {
    id: 78, // Was Table #75
    programName: "Arab Cinema Lab (Malmö AFF)",
    description: "Distribution support for short films",
    targetRegion: "Arab Shorts",
    applicationCountry: "Sweden",
    submissionDates: "Check MAFF Website",
    websiteLink: "https://maffswe.com/", // Check specific MAFF sections
    category: "Distribution" // Short film focus
  },
  {
    id: 79, // Was Table #76
    programName: "Network of Arab Alternative Screens (NAAS)",
    description: "Supports alternative cinemas in the Arab region",
    targetRegion: "Member Screens / Arab Films",
    applicationCountry: "Regional",
    submissionDates: "Membership/Varies",
    websiteLink: "https://www.naasnetwork.org/",
    category: "Distribution" // Exhibition Support Network
  },

  // Festival Awards with Cash Prizes (Selection)
  // ID 20 (Tanit d'Or - JCC) already covered
  {
    id: 80, // Was Table #79
    programName: "El Gouna Star Awards (El Gouna Film Festival)",
    description: "Competition Awards (Features, Docs, Shorts)",
    targetRegion: "Arab & International Films",
    applicationCountry: "Egypt",
    submissionDates: "Annual (During GFF)",
    websiteLink: "https://elgounafilmfestival.com/",
    category: "Festival Awards"
  },
  {
    id: 81, // Was Table #80
    programName: "Muhr Awards (Dubai Int'l Film Festival - Former)",
    description: "Major Competition Awards for Arab Cinema",
    targetRegion: "Arab Films",
    applicationCountry: "UAE",
    submissionDates: "Festival Paused/Ended",
    websiteLink: "", // No active link
    category: "Historical"
  },
  {
    id: 82, // Was Table #81
    programName: "Red Sea Int'l Film Festival Awards (Yusr Awards)",
    description: "Yusr Awards (Features, Shorts, VR)",
    targetRegion: "Arab, African, Asian, International Films",
    applicationCountry: "Saudi Arabia",
    submissionDates: "Annual (During Festival)",
    websiteLink: "https://redseafilmfest.com/en/",
    category: "Festival Awards"
  },
  {
    id: 83, // Was Table #82
    programName: "Cairo Int'l Film Festival (CIFF) Awards",
    description: "Golden Pyramid, Competition Awards",
    targetRegion: "International & Arab Films",
    applicationCountry: "Egypt",
    submissionDates: "Annual (During CIFF)",
    websiteLink: "https://www.ciff.org.eg/",
    category: "Festival Awards"
  },
  {
    id: 84, // Was Table #83
    programName: "Marrakech Int'l Film Festival Awards",
    description: "Étoile d'Or, Jury Prize, etc.",
    targetRegion: "International Feature Films",
    applicationCountry: "Morocco",
    submissionDates: "Annual (During FIFM)",
    websiteLink: "https://marrakech-festival.com/en/",
    category: "Festival Awards"
  },
  {
    id: 85, // Was Table #84
    programName: "Malmö Arab Film Festival Awards",
    description: "Competition Awards (Features, Docs, Shorts)",
    targetRegion: "Arab Films",
    applicationCountry: "Sweden",
    submissionDates: "Annual (During MAFF)",
    websiteLink: "https://maffswe.com/",
    category: "Festival Awards"
  },
  {
    id: 86, // Was Table #85 (& potentially #78)
    programName: "Amman International Film Festival (AIFF) Awards (Black Iris)",
    description: "Black Iris Awards (Debut Arab Features, Docs, Shorts)",
    targetRegion: "First/Second time Arab filmmakers",
    applicationCountry: "Jordan",
    submissionDates: "Annual (During AIFF)",
    websiteLink: "https://aiff.jo/",
    category: "Festival Awards"
  },
  {
    id: 87, // Was Table #86
    programName: "Oran International Arab Film Festival (WOIFF) Awards",
    description: "Wihr d'Or Awards",
    targetRegion: "Arab Films",
    applicationCountry: "Algeria",
    submissionDates: "Annual - Check Website/News",
    websiteLink: "", // Festival website varies
    category: "Festival Awards"
  },
  {
    id: 88, // Was Table #87
    programName: "Baghdad International Film Festival Awards",
    description: "Competition Awards",
    targetRegion: "Iraqi & International Films",
    applicationCountry: "Iraq",
    submissionDates: "Check Festival Website/News",
    websiteLink: "", // Festival status/website varies
    category: "Festival Awards"
  },
  {
    id: 89, // Was Table #88
    programName: "Tripoli Film Festival Awards",
    description: "Competition Awards",
    targetRegion: "Lebanese & International Films",
    applicationCountry: "Lebanon",
    submissionDates: "Annual - Check Festival Website/News",
    websiteLink: "", // Festival website varies
    category: "Festival Awards"
  },
  {
    id: 90, // Was Table #89
    programName: "Karama Human Rights Film Festival Awards",
    description: "Awards related to Human Rights themes",
    targetRegion: "Films focusing on Human Rights",
    applicationCountry: "Jordan (Network)",
    submissionDates: "Annual",
    websiteLink: "https://www.humanrightsfilmnetwork.org/festivals/karama-human-rights-film-festival", // Network link
    category: "Festival Awards"
  },
  {
    id: 91, // Was Table #90
    programName: "Palestine Cinema Days Awards (Sunbird Award)",
    description: "Sunbird Award Competition (Shorts, Docs)",
    targetRegion: "Palestinian & International",
    applicationCountry: "Palestine",
    submissionDates: "Annual",
    websiteLink: "https://www.flp.ps/en", // Via FilmLab Palestine
    category: "Festival Awards"
  },

  // Other Platforms & Resources
  {
    id: 92, // Was Table #91
    programName: "Daleel Film",
    description: "Database/Directory of Film Professionals & Companies",
    targetRegion: "MENA Region",
    applicationCountry: "Regional",
    submissionDates: "Ongoing",
    websiteLink: "https://www.daleel.film/",
    category: "Resources"
  },
  {
    id: 93, // Was Table #92
    programName: "ScreenDaily",
    description: "Industry News, Festival Reports, Funding Announcements",
    targetRegion: "International",
    applicationCountry: "UK",
    submissionDates: "Ongoing",
    websiteLink: "https://www.screendaily.com/",
    category: "Resources"
  },
  {
    id: 94, // Was Table #93
    programName: "Cineuropa",
    description: "News, Databases (Incl. Funding Guide, Co-productions)",
    targetRegion: "European focus, but covers MENA co-pros/funds",
    applicationCountry: "Belgium (EU)",
    submissionDates: "Ongoing",
    websiteLink: "https://cineuropa.org/en/",
    category: "Resources"
  },
  {
    id: 95, // Was Table #94
    programName: "On The Move",
    description: "Cultural Mobility Funding Database",
    targetRegion: "International",
    applicationCountry: "Belgium (Int'l)",
    submissionDates: "Ongoing Updates",
    websiteLink: "https://on-the-move.org/",
    category: "Resources"
  },
  {
    id: 96, // Was Table #95
    programName: "TransArtists",
    description: "Artist Residency & Funding Database",
    targetRegion: "International",
    applicationCountry: "Netherlands (Int'l)",
    submissionDates: "Ongoing Updates",
    websiteLink: "https://www.transartists.org/",
    category: "Resources"
  },
  {
    id: 97, // Was Table #96
    programName: "Festagent",
    description: "Festival Submission Platform & Database",
    targetRegion: "International",
    applicationCountry: "International",
    submissionDates: "Ongoing",
    websiteLink: "https://festagent.com/en",
    category: "Platform"
  },
  {
    id: 98, // Was Table #97
    programName: "Festival Scope Pro / Festival Scope",
    description: "Online platform for film professionals / curated films",
    targetRegion: "International",
    applicationCountry: "International",
    submissionDates: "Ongoing",
    websiteLink: "https://pro.festivalscope.com/", // Pro link
    category: "Platform"
  },
  {
    id: 99, // Was Table #98
    programName: "Méditerranée Audiovisuelle",
    description: "News and resources related to Mediterranean audiovisual sector",
    targetRegion: "Mediterranean Region (Incl. MENA)",
    applicationCountry: "Regional",
    submissionDates: "Ongoing",
    websiteLink: "https://mediterranee-audiovisuelle.com/?lang=en",
    category: "Resources"
  },
  {
    id: 100, // Was Table #99
    programName: "Africine",
    description: "Database and news on African cinema (Incl. North Africa)",
    targetRegion: "African Continent",
    applicationCountry: "Regional",
    submissionDates: "Ongoing",
    websiteLink: "https://www.africine.org/",
    category: "Resources"
  },
  {
    id: 101, // Was Table #100
    programName: "Cinematunisien.com",
    description: "News and resources on Tunisian cinema",
    targetRegion: "Tunisia",
    applicationCountry: "Tunisia",
    submissionDates: "Ongoing",
    websiteLink: "https://cinematunisien.com/",
    category: "Resources"
  },
  {
    id: 102, // Was Table #101
    programName: "Aflam (Marseille)",
    description: "Festival & initiatives promoting Arab cinema",
    targetRegion: "Arab Cinema",
    applicationCountry: "France",
    submissionDates: "Annual Festival & Events",
    websiteLink: "https://www.aflam.fr/",
    category: "Platform" // Festival/Promotional Platform
  },
  {
    id: 103, // Was Table #102
    programName: "Screen Arabia",
    description: "Industry Directory & News",
    targetRegion: "MENA Region",
    applicationCountry: "Regional",
    submissionDates: "Ongoing",
    websiteLink: "https://screenarabia.com/",
    category: "Resources"
  },
  {
    id: 104, // Was Table #103
    programName: "Mawred Al Thaqafy (Culture Resource)",
    description: "Grants for Arts & Culture (Sometimes includes film/video)",
    targetRegion: "Arab Region",
    applicationCountry: "Lebanon (Regional)",
    submissionDates: "Check Website for Calls",
    websiteLink: "https://mawred.org/",
    category: "Regional Support" // Broader cultural fund
  },
  {
    id: 105, // Was Table #104
    programName: "Ettijahat - Independent Culture",
    description: "Grants & Labs for Syrian & Arab artists (Incl. Film/AV)",
    targetRegion: "Syrian & Arab Artists",
    applicationCountry: "Regional/Int'l",
    submissionDates: "Check Website for Calls",
    websiteLink: "https://ettijahat.org/",
    category: "Regional Support" // Arts fund with film components
  },
  {
    id: 106, // Was Table #105
    programName: "Arab Film & Media Institute (AFMI) - USA",
    description: "Programs supporting Arab filmmakers in the US diaspora & beyond",
    targetRegion: "Arab filmmakers (US focus, but broader reach)",
    applicationCountry: "USA",
    submissionDates: "Varies - Check Website",
    websiteLink: "https://arabfilm.us/",
    category: "Regional Support" // Diaspora focused
  },
  {
    id: 107, // Was Table #106
    programName: "TheViewer",
    description: "Online platform for secure screener sharing & pitching",
    targetRegion: "International",
    applicationCountry: "International",
    submissionDates: "Subscription/Ongoing",
    websiteLink: "https://theviewer.co/",
    category: "Platform" // Industry Tool
  },
  {
    id: 108, // Was Table #107
    programName: "Fondation Liban Cinéma (FLC)",
    description: "Support initiatives for Lebanese Cinema",
    targetRegion: "Lebanese Filmmakers",
    applicationCountry: "Lebanon",
    submissionDates: "Varies - Check Website (Check Activity Status)",
    websiteLink: "http://www.fondationlibancinema.org/",
    category: "National"
  },
  {
    id: 109, // Was Table #109
    programName: "Sudan Film Factory",
    description: "Training and support for Sudanese filmmakers",
    targetRegion: "Sudanese Filmmakers",
    applicationCountry: "Sudan",
    submissionDates: "Check Social Media/Local News for Updates",
    websiteLink: "", // Search for recent activity
    category: "National" // Local support initiative
  },
  {
    id: 110, // Was Table #110
    programName: "Yemen Art Base",
    description: "Support for Yemeni artists (potentially including film)",
    targetRegion: "Yemeni Artists",
    applicationCountry: "Germany/Yemen",
    submissionDates: "Check Website for Calls",
    websiteLink: "https://yemenartbase.com/",
    category: "Regional Support" // Supports Yemeni artists
  },
  {
    id: 111, // Was Table #111
    programName: "IRAQima",
    description: "Platform supporting emerging Iraqi filmmakers",
    targetRegion: "Iraqi Filmmakers",
    applicationCountry: "Iraq/International",
    submissionDates: "Varies - Check Website/Social Media",
    websiteLink: "", // Search for recent activity
    category: "Platform" // Support platform
  },
];