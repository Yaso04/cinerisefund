export interface FilmFund {
  id: number;
  programName: string;
  description: string;
  targetRegion: string;
  applicationCountry: string;
  submissionDates: string;
  websiteLink: string;
  category: 'Major Regional' | 'International' | 'National' | 'Labs' | 'Distribution' | 'Festival Awards' | 'Other';
}

export type SortOption = 'programName' | 'applicationCountry' | 'category' | 'targetRegion';